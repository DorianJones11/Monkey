var backImage,backgr;

var player, player_running;

var ground,ground_img;

var bananaGroup, bananaImage;

var rockGroup, rock_img; var

 gameOver; 

var restart; 

var score=0; 
var end = 0;
var play = 1
var gameState = play 

function preload()
{ backImage=loadImage("jungle2.jpg"); player_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png"); 
 
 bananaImage = loadImage("Banana.png"); 
 rock_img = loadImage("stone.png");
} 

function setup() 
{ createCanvas(800,400); 
 
 backgr=createSprite(0,0,800,400); 
 backgr.addImage(backImage); 
 backgr.scale=1.5; 
 backgr.x=backgr.width/2; 
 backgr.velocityX=-4; 
 
 player = createSprite(100,340,20,50); player.addAnimation("Running",player_running); 
 player.scale = 0.1;
 
 ground = createSprite(400,350,800,10);
 ground.velocityX=-4; 
 ground.x=ground.width/2; 
 ground.visible=false; 
 
 bananaGroup = new Group(); 
 rockGroup = new Group(); 
 score = 0; 
} 

function draw() {
 background(255); 
  
  if (ground.x < 0)
  {
      ground.x = ground.width/2;
    }

 player.setCollider("circle",0,0,40); 
 player.collide(ground); 

 if(gameState === play) 
  //gameOver and restart keys visable ground.
   velocityX = -6; 
  
   score = score + Math.round(World.frameCount/250);
  
   if (ground.x < 0) 
   { 
     ground.x = ground.width/2;
   }
  
   if(keyDown("space") && player.y >= 310)
   { 
     player.velocityY = -12 ; 
   }
  
   player.velocityY = player.velocityY + 0.8; 
  
   spawnBanana(); 
   spawnRock(); 
  
   if(player.isTouching(rockGroup))
   {
    player.scale=0.2
   }
  
   if(bananaGroup.isTouching(player)) 
   { 
    BananaGroup.destroyEach();
     
   }
  
   if(gameState === end) 
     
   { gameOver.visible = true;
    restart.visible = true; 
    ground.velocityX = 0; 
    monkey.velocityY = 0; 
    RockGroup.setVelocityXEach(0);
    BananaGroup.setVelocityXEach(0); 
    RockGroup.setLifetimeEach(-1); 
    BananaGroup.setLifetimeEach(-1); 
    score = 0; 
   }
    
   
   drawSprites();
   
 } 
 
 function spawnRock() 

 { if(World.frameCount % 100 === 0) {
   rock = createSprite(350,340,10,40); 
   rock.velocityX = -(5+5*score/300); 
   rock.addImage(rock_img); 
   rock.scale = 0.5; 
   rock.lifetime = 150; 
   rock.scale = .1;
 } 
   } 
 
 function spawnBanana()

  { if (World.frameCount % 150 === 0) 
 { banana = createSprite(400,320,40,10); 
  banana.y = random(200,300); 
  banana.addImage(bananaImage);
  banana.scale = 0.5; 
  banana.velocityX = -3; 
  banana.lifetime = 134; 
  banana.depth = banana.depth; 
  player.depth = banana.depth + 1; 
  banana.scale = 0.05 
 } 
  } 
 
 function reset() 
{
  if (gameState = play) 
  {
    RockGroup.destroyEach(); BananaGroup.destroyEach(); 
  //restart.visble = false; 
  //gameOver.visible = false; score=0;
  }
 }


  
